import {
  Component,
  OnInit
} from "@angular/core";
import {
  AuthService
} from "../../services/auth.service";
import {
  RoleCode
} from "src/app/constant/role.code";
import {
  Route,
  Router
} from "@angular/router";
import {
  MenuItem
} from 'primeng/api';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html'
})

export class NavbarComponent implements OnInit {

  imgUrl!: number;
  roleCode!: string;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  // ngOnInit():void{
  //     const profile = this.authService.getProfile();
  //     if(profile){
  //         this.imgUrl = profile.photoId;
  //             this.roleCode = profile.roleCode
  //     }
  // }

  get isAdmin() {
    return this.roleCode == RoleCode.SUPERADMIN
    return true;
  }

  get isPic() {
    return this.roleCode == RoleCode.PIC
    return true;
  }

  get isCustomer() {
    return this.roleCode == RoleCode.CUST
    return true;
  }

  get isDeveloper() {
    return this.roleCode == RoleCode.DEVELOPER
    return true;
  }

  logout(): void {
    localStorage.clear();
    this.router.navigateByUrl("/login");
  }

  // contoh
  items: MenuItem[] | undefined;

  ngOnInit() {
    //
    const profile = this.authService.getProfile();
    if (profile) {
      this.imgUrl = profile.photoId;
      this.roleCode = profile.roleCode
    }
    //Primeng
    this.items = [{
        label: 'Ticketing - Torangto',
        routerLink: "/dashboard",
      },{
        label: 'Home',
        routerLink: "/dashboard",
      },
      {
        label: 'Master Data',
        items: [{
            label: 'List-User',
            routerLink: "/users",
            visible : this.isAdmin
          },
          {
            label: 'Company',
            routerLink: "/companies",
            visible : this.isAdmin
          },
          {
            label: 'Product List',
            routerLink: "/products",
            visible : this.isAdmin
          },
          {
            label: 'Subscribed Product',
            routerLink: "/subscriber",
            visible : this.isAdmin
          },
          {
            label: 'PIC Customer',
            routerLink: "/pic-customer",
            visible : this.isAdmin
          },
          {
            label: 'My Subscribed Product',
            routerLink: "/subscriber",
            visible : this.isCustomer
          },
          {
            label: 'My Ticket (User)',
            routerLink: "/tickets",
            visible : this.isCustomer
          },
          {
            label: 'My Ticket (PIC)',
            routerLink: "/tickets/ticket-pic",
            visible : this.isPic
          },
          {
            label: 'My Ticket (Dev)',
            routerLink: "/tickets",
            visible : this.isDeveloper
          }
        ]
      },
      {
        label: 'Users',
        icon: 'pi pi-fw pi-user',
        items: [{
            label: 'New',
            icon: 'pi pi-fw pi-user-plus'
          },
          {
            label: 'Delete',
            icon: 'pi pi-fw pi-user-minus'
          },
          {
            label: 'Search',
            icon: 'pi pi-fw pi-users',
            items: [{
                label: 'Filter',
                icon: 'pi pi-fw pi-filter',
                items: [{
                  label: 'Print',
                  icon: 'pi pi-fw pi-print'
                }]
              },
              {
                icon: 'pi pi-fw pi-bars',
                label: 'List'
              }
            ]
          }
        ]
      },
      {
        label: 'Events',
        icon: 'pi pi-fw pi-calendar',
        items: [{
            label: 'Edit',
            icon: 'pi pi-fw pi-pencil',
            items: [{
                label: 'Save',
                icon: 'pi pi-fw pi-calendar-plus'
              },
              {
                label: 'Delete',
                icon: 'pi pi-fw pi-calendar-minus'
              }
            ]
          },
          {
            label: 'Archieve',
            icon: 'pi pi-fw pi-calendar-times',
            items: [{
              label: 'Remove',
              icon: 'pi pi-fw pi-calendar-minus'
            }]
          }
        ]
      },
      {
        label: 'Quit',
        icon: 'pi pi-fw pi-power-off',
        command: () => {
          this.logout()
        }
      }
    ];
  }
}