export enum RoleName {
    SUPERADMIN = 'SuperAdmin',
    PIC = "PIC",
    DEVELOPER = "Developer",
    CUST = "Customer"
}

export enum RoleCode {
    SUPERADMIN = 'ADM',
    PIC = "PIC",
    DEVELOPER = "DEV",
    CUST = "CST"
}