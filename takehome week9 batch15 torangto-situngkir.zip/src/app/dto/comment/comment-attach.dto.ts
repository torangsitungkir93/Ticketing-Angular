export interface CommentAttachDto {
    attachmentId: number;
    file: string;
    ext: string;
  }
  