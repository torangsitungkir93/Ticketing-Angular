export interface CommentAttachReqDto {
    ticketId: number;
  }
  