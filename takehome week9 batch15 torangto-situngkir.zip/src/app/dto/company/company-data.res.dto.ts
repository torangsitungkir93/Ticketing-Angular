export interface CompanyDataResDto {
    id: number;
    companyCode: string;
    companyName: string;
    companyAddress: string;
    fileId: number;
    files: string;
    ext: string;
    isActive: boolean;
  }
  