export interface CompanyUpdateReqDto {
    companyId: number;
    code: string;
    name: string;
    address: string;
    files: string;
    ext: string;
  }
  
  