export interface CompanyInsertReqDto {
    companyName: string;
    companyAddress: string;
    companyCode: string;
    file: string;
    ext: string;
  }
  