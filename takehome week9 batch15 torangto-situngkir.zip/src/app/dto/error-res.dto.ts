export interface ErrorResDto {
	message:string;
}