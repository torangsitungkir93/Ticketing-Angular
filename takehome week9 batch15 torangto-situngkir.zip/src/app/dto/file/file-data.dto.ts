export interface FileDataDto {
	ext : string;
	files : string;
}
