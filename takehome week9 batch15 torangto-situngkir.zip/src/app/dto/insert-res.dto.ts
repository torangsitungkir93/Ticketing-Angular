export interface InsertResDto {

	id:number;
	message:string;
}