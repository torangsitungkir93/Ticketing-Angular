export interface LoginResDto {
    id: number;
    roleCode: string;
    token: string;
    fullName: string;
    photoId :number;
  }
  