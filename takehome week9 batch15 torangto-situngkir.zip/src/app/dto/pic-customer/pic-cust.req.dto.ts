export interface PicCustReqDto {
    picId: number;
    customerId: number;
  }
  