export interface PicCustResDto {
  id : number;
	picName : string;
	custName: string;
  }
  