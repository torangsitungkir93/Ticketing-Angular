export interface TicketPriorityResDto {
    id: number;
    priorityCode: string;
    priorityName: string;
  }
  