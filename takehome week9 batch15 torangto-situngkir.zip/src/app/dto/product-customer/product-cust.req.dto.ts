export interface ProductCustReqDto {
	productId : number;
	customerId : number;
}