export interface ProductCustResDto {
	id:number;
	productCode:string;
	productName:string;
	customerName:string;
}