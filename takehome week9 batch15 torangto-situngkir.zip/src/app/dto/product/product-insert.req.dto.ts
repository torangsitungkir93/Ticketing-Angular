export interface ProductInsertReqDto {
	productCode : string;
	productName : string;
}