export interface ProductUpdateReqDto {
	
	id : number;
	productCode : string;
	productName:string;
}