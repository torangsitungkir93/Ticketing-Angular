export interface ProductResDto {
	
	id : number;
	productCode : string;
	productName:string;
}