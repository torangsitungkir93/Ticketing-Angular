export interface RoleResDto {
	id:number;
	roleCode:string;
	roleName:string;
}