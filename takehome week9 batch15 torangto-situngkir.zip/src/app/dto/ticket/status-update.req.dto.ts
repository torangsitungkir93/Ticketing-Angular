export interface StatusUpdateReqDto {
	roleCode : string;
	statusCode : string;
	ticketId : number;
}