export interface TicketAttachDto {
    attachmentId: number;
    file: string;
    ext: string;
  }
  