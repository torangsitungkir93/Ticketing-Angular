export interface UpdateResDto {
    version: number;
    message: string;
  }
  