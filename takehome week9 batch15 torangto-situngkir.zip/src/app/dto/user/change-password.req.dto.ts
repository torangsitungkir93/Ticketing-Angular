export interface ChangePasswordReqDto {
    oldPassword: string;
    newPassword: string;
}