export interface UserDetailResDto {
    id: number;
    profileName: string;
    roleName: string;
    email: string;
    phone: string;
    address: string;
    photoId: number;
    companyName : string;
}