export interface UserInsertReqDto {
  userEmail: string;
  roleId: number;
  companyId: number;
  userName: string;
  userPhone: string;
  userAddress: string;
  ext: string;
  file: string;
}
