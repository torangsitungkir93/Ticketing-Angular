export interface UserResDto {
  id : number;
  profileName: string;
  roleName: string;
  roleCode: string;
}