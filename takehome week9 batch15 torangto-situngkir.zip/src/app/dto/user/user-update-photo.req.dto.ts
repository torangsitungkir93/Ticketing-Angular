export interface UserUpdatePhotoReqDto {
  userId: number;
  ext: string;
  file: string;
}