export interface UserUpdatePhotoResDto {
	message : string;
	profileId : number;
	ext : string;
	file : string;
}