export interface UsersResDto {
    id: number;
    userName: string;
    roleName: string;
    roleCode: string;
  }
  