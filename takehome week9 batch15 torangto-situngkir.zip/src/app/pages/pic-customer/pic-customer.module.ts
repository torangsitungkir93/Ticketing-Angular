import { NgModule } from "@angular/core";
import { PicCustomerRouting } from "./pic-customer.routing";


@NgModule({
    imports : [
        PicCustomerRouting
    ]
})

export class PicCustModule{

}