import { NgModule } from "@angular/core";
import { ProductRouting } from "./product.routing";


@NgModule({
    imports : [
        ProductRouting
    ]
})

export class ProductModule{

}