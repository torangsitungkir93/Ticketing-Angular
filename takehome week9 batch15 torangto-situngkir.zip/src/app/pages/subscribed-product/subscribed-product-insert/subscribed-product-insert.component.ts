import { Component } from "@angular/core";

@Component({
    selector : 'subscribed-product-insert',
    templateUrl : './subscribed-product-insert.component.html'
})

export class SubcribedProductInsertComponent{
    
}