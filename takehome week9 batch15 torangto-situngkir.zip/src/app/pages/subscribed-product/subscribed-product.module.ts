import { NgModule } from "@angular/core";
import { SubscribedRouting } from "./subscribed-product.routing";


@NgModule({
    imports : [
        SubscribedRouting
    ]
})

export class subscribedModule{

}