import { Component } from "@angular/core";

@Component({
    selector : 'ticket-update',
    templateUrl : './ticket-update.component.html'
})
export class TicketUpdateComponent{

}