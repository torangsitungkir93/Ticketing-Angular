import { NgModule } from "@angular/core";
import { TicketRouting } from "./ticket.routing";


@NgModule({
    imports : [
        TicketRouting
    ]
})
export class TicketModule{

}