import { Component } from "@angular/core";

@Component({
    selector : 'user-change-photo',
    templateUrl : './user-change-photo.html'
})
export class UserChangePhoto {
    
}